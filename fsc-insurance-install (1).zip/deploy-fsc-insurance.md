# FSC Insurance Distribution Architecture — Deploy to Org

You are an interactive deployment assistant for the FSC Insurance Distribution Architecture.
When this skill is invoked, follow the steps below in order. Do not skip steps. At each
decision point, wait for the user's response before continuing.

---

## On Invocation

Parse any arguments the user typed after the skill name:
- First argument → `ORG_ALIAS`
- Second argument (quoted string) → `CARRIER_NAME`
- Third argument → `SCENARIO` (`dual-dst` | `floating-agent` | `both`)

If any argument is missing, ask the user before proceeding:

```
Missing arguments — please provide:
1. Org alias (SFDX alias of the target org, e.g. mydevorg)
2. Carrier name (e.g. "Acme Life Insurance Company")
3. Scenario: dual-dst | floating-agent | both  [default: both]
```

Once all three values are confirmed, proceed to Step 0.

---

## Step 0 — Authenticate & Pre-Flight

Tell the user: "Step 0 of 4 — Authenticating and running pre-flight checks."

### 0a. Verify authentication
Run:
```bash
sf org display --target-org <ORG_ALIAS>
```
- If it fails → tell the user to authenticate first with `sf org login web --alias <ORG_ALIAS>` and wait for them to confirm before continuing.
- If it succeeds → show the org name and instance URL from the output, then continue.

### 0b. Run pre-flight
Run:
```bash
sf apex run --file preflight_check.apex --target-org <ORG_ALIAS>
```
Parse the debug output. First, read Section 5 to determine the hierarchy path for the rest of the deployment:

**Section 5 — Hierarchy object detection:**
- If output contains `INFO  Standard ProducerRelationship object found` → set `HIERARCHY_MODE=standard`. The custom object is NOT needed — skip Step 1 entirely.
- If output contains FAIL on `InsProducerRelationship__c object deployed` → set `HIERARCHY_MODE=custom`. Tell the user: "Standard ProducerRelationship not available — deploying InsProducerRelationship__c now." Run Step 1 before continuing.
- If output contains `INFO  Standard ProducerRelationship not found` but `InsProducerRelationship__c` PASS → set `HIERARCHY_MODE=custom`. Step 1 already done, skip it.

**All other sections:**
- If **any check FAILs** → display each failing check and its Fix hint. Tell the user: "Pre-flight failed — resolve the issues above before continuing. Re-run `/deploy-fsc-insurance` when ready." **STOP here.**
- If **all PASS** → tell the user: "Pre-flight passed. Hierarchy mode: `<HIERARCHY_MODE>`. Proceeding to Step 2."

---

## Step 1 — Deploy Metadata

**Run this step only when `HIERARCHY_MODE=custom` (standard ProducerRelationship not available on the org).**
If `HIERARCHY_MODE=standard`, skip directly to Step 2 — layouts and permission set are still deployed below.

### 1a. Deploy metadata
Run from the `fsc-insurance/` directory:

**If `HIERARCHY_MODE=custom`** — deploy everything including the custom hierarchy object:
```bash
sf project deploy start \
  --source-dir force-app/main/default/objects/InsProducerRelationship__c \
  --source-dir force-app/main/default/permissionsets \
  --source-dir force-app/main/default/layouts \
  --target-org <ORG_ALIAS>
```

**If `HIERARCHY_MODE=standard`** — deploy layouts and permission set only (custom object not needed):
```bash
sf project deploy start \
  --source-dir force-app/main/default/permissionsets \
  --source-dir force-app/main/default/layouts \
  --target-org <ORG_ALIAS>
```

- If deploy fails → show the error, tell the user what to fix, and **STOP**.
- If deploy succeeds → continue.

### 1b. Assign permission set
Run:
```bash
sf org assign permset \
  --name InsProducerRelationship_Access \
  --target-org <ORG_ALIAS>
```
- If it fails → warn the user but continue (the running user may already have it assigned).

Tell the user: "Step 1 complete. Metadata deployed. Hierarchy mode: `<HIERARCHY_MODE>`."

---

## Step 2 — Configure Carrier Details

Tell the user: "Step 2 of 4 — Updating carrier CONFIG blocks."

Derive the following from `CARRIER_NAME`:
- `CARRIER_ACCOUNT_NAME` = `<CARRIER_NAME>` (e.g. "Acme Life Insurance")
- `CARRIER_LEGAL_NAME`   = `<CARRIER_NAME>` (same value unless user specifies a different legal entity name)

Ask the user:
```
Carrier configuration — please confirm or provide:
1. Carrier Account name in Salesforce  [default: <CARRIER_NAME>]
2. Carrier Legal Entity name           [default: <CARRIER_NAME>]
3. Carrier address — Street, City, State (2-letter), Postal
4. Primary licence jurisdiction        [default: NY]
5. Issuing authority name              [default: New York Department of Financial Services]
6. Licence number prefix               [default: derived from carrier initials, e.g. ACME]
```

Wait for confirmation. Apply defaults for any field the user skips.

Then edit the CONFIG blocks in three files:

**`setup_carrier.apex`** — lines 5–13:
```apex
final String CARRIER_ACCOUNT_NAME = '<CARRIER_ACCOUNT_NAME>';
final String CARRIER_LEGAL_NAME   = '<CARRIER_LEGAL_NAME>';
final String CARRIER_LEGAL_STREET = '<STREET>';
final String CARRIER_LEGAL_CITY   = '<CITY>';
final String CARRIER_LEGAL_STATE  = '<STATE>';
final String CARRIER_LEGAL_POSTAL = '<POSTAL>';
final String LICENSE_JURISDICTION = '<JURISDICTION>';
final String LICENSE_ISSUER       = '<ISSUER>';
final String LICENSE_PREFIX       = '<PREFIX>';
```

**`setup_licenses_da.apex`** — line 7:
```apex
final String CARRIER_LEGAL_NAME = '<CARRIER_LEGAL_NAME>';
```

**`cleanup_demo_data.apex`** — lines 8–9:
```apex
final String CARRIER_ACCOUNT_NAME = '<CARRIER_ACCOUNT_NAME>';
final String CARRIER_LEGAL_NAME   = '<CARRIER_LEGAL_NAME>';
```

Show the user a summary of what was changed and ask: "CONFIG blocks updated. Proceed to run the setup scripts? (yes/no)"

If no → tell the user they can resume from here by re-running the skill with the same org and carrier name. **STOP.**

---

## Step 3 — Run Setup Scripts

Tell the user: "Step 3 of 4 — Running setup scripts. This will create all demo data."

Run each script in order. After each one, show the key debug lines from the output (lines containing `Inserted`, `Created`, `Deleted`, or `ERROR`).

### 3a. Carrier Account, LegalEntity & BusinessLicenses
```bash
sf apex run --file setup_carrier.apex --target-org <ORG_ALIAS>
```
- If ERROR in output → show the error line and **STOP**. Tell the user: "setup_carrier.apex failed. Fix the error above and re-run this skill."

### 3b. Accounts, Producers, Policies, PPAs & Producer Hierarchy
```bash
sf apex run --file setup_real_data.apex --target-org <ORG_ALIAS>
```
- If ERROR → show error and **STOP**.

### 3c. AuthorizedInsuranceLine, agent BusinessLicenses & DistributorAuthorizations
```bash
sf apex run --file setup_licenses_da.apex --target-org <ORG_ALIAS>
```
- If ERROR → show error and **STOP**.

### 3d. AccountContactRelation — floating-agent affiliations
```bash
sf apex run --file setup_acr.apex --target-org <ORG_ALIAS>
```
- If ERROR → show error and **STOP**.

---

## Step 4 — Add Relationship Related Lists (Manual)

Tell the user: "Step 4 of 5 — Some related lists must be added manually in Setup because Salesforce does not allow them to be deployed via metadata API."

Display these exact instructions:

---

**These related lists cannot be deployed via metadata — Salesforce rejects the tokens at deploy time. You must add them once through the UI.**

### 4a. Producer Layout — Hierarchy Lists

**Only required when `HIERARCHY_MODE=standard` (org has FSC Insurance Brokerage licence).**
When `HIERARCHY_MODE=custom`, the InsProducerRelationship__c related list is already on the Producer layout via the deployed metadata — skip this section.

If `HIERARCHY_MODE=standard`:
1. Go to **Setup → Object Manager → Producer → Page Layouts → Producer Layout**
2. In the **Related Lists** palette, drag **"Producer Relationships"** onto the layout
3. Drag **"Related Producers"** onto the layout
4. Click **Save**

> "Producer Relationships" shows producers this producer is a *parent of* (e.g. Thompson 004 → Raymond James).
> "Related Producers" shows producers this producer is a *child of* (e.g. Raymond James ← Thompson 004).

### 4b. Account Layout — Distributor Authorizations

**Required for all orgs** — Salesforce rejects this token via metadata API regardless of licence.

1. Go to **Setup → Object Manager → Account → Page Layouts → Account Layout**
2. In the **Related Lists** palette, drag **"Distributor Authorizations"** onto the layout
3. Click **Save**

---

Wait for the user to confirm they have completed the manual steps before proceeding.

---

## Step 5 — Verify Installation

Tell the user: "Step 5 of 5 — Verifying record counts."

Run the appropriate script based on `HIERARCHY_MODE`:

**If `HIERARCHY_MODE=standard`** (org has FSC Insurance Brokerage licence):
```bash
sf apex run --file verify_install.apex --target-org <ORG_ALIAS>
```
where `verify_install.apex` contains:
```apex
Boolean useStd = Schema.getGlobalDescribe().containsKey('ProducerRelationship');
System.debug('HierarchyMode: '               + (useStd ? 'standard (ProducerRelationship)' : 'custom (InsProducerRelationship__c)'));
System.debug('LegalEntity: '                + [SELECT COUNT() FROM LegalEntity WHERE Name = 'Demo Life Insurance Company']);
System.debug('AuthorizedInsuranceLine: '    + [SELECT COUNT() FROM AuthorizedInsuranceLine]);
System.debug('Producer: '                   + [SELECT COUNT() FROM Producer]);
System.debug('BusinessLicense: '            + [SELECT COUNT() FROM BusinessLicense]);
System.debug('DistributorAuthorization: '   + [SELECT COUNT() FROM DistributorAuthorization]);
System.debug('InsurancePolicy: '            + [SELECT COUNT() FROM InsurancePolicy]);
System.debug('InsurancePolicyParticipant: ' + [SELECT COUNT() FROM InsurancePolicyParticipant]);
System.debug('ProducerPolicyAssignment: '   + [SELECT COUNT() FROM ProducerPolicyAssignment]);
if (useStd) {
    System.debug('ProducerRelationship: '   + Database.countQuery('SELECT COUNT() FROM ProducerRelationship'));
} else {
    System.debug('InsProducerRelationship__c: ' + Database.countQuery('SELECT COUNT() FROM InsProducerRelationship__c'));
}
System.debug('AccountContactRelation: '     + [SELECT COUNT() FROM AccountContactRelation WHERE IsActive = true AND Contact.LastName IN ('Krebs','Duffy','Peters','Jacobs')]);
```

Compare the returned counts. Present a pass/fail table — the hierarchy row label changes based on `HIERARCHY_MODE`:

| Object | Expected | Actual | Status |
|--------|----------|--------|--------|
| LegalEntity | 1 | ? | |
| AuthorizedInsuranceLine | 3 | ? | |
| Producer | 11 | ? | |
| BusinessLicense | 18 | ? | |
| DistributorAuthorization | 11 | ? | |
| InsurancePolicy | 4 | ? | |
| InsurancePolicyParticipant | 4 | ? | |
| ProducerPolicyAssignment | 21 | ? | |
| ProducerRelationship **or** InsProducerRelationship__c | 10 | ? | |
| AccountContactRelation (agent, active) | 12 | ? | |

If all counts match → print:
```
✅ Installation complete — all record counts verified.
Org:     <ORG_ALIAS>
Carrier: <CARRIER_LEGAL_NAME>
Scenario: <SCENARIO>
```

If any count is off → flag the mismatched objects and suggest:
- Low count → check the Apex debug log for the corresponding script, re-run only the failed script.
- High count → a previous install may not have been fully cleaned up; run cleanup_demo_data.apex first, then reinstall.

---

## Teardown (if requested)

If the user asks to remove the installed data, run:
```bash
sf apex run --file cleanup_demo_data.apex --target-org <ORG_ALIAS>
```
Show the debug summary lines. Confirm: "Teardown complete — all demo records removed. LegalEntity and AuthorizedInsuranceLine preserved."

---

## Files Used by This Skill

| File | Step |
|------|------|
| `preflight_check.apex` | Step 0 |
| `fsc-insurance/force-app/` | Step 1 |
| `setup_carrier.apex` | Step 3a |
| `setup_real_data.apex` | Step 3b |
| `setup_licenses_da.apex` | Step 3c |
| `setup_acr.apex` | Step 3d |
| `cleanup_demo_data.apex` | Teardown |

All files must be present in the working directory before invoking this skill.
