# FSC Lead Ingestion for Auto Quote — Capability Learning Kit

## Who This Is For

- Salesforce developers/admins new to **insurance industry implementations**
- Developers who haven't built **Platform Event-based integrations** before
- Anyone wanting to understand how real insurance companies ingest online quote requests

---

## The Business Problem (Plain English)

**Scenario:** A customer goes to the AAA Insurance website, fills out an auto insurance quote form
(enters their car details, driving history, address), and the website's quote engine calculates
a premium. Now that quote data needs to get INTO Salesforce so an insurance agent can follow up.

**Why is this hard?**
- The website/quote engine is a completely separate system (not Salesforce)
- Thousands of customers might submit quotes simultaneously
- The customer might already exist in Salesforce (they have a home insurance policy)
- Different quote statuses need different handling (a "bind" means they already bought it)
- The data is complex — nested JSON with vehicles, drivers, coverage details

**What this kit teaches:** How to build a real-time bridge between an external quoting system
and Salesforce using Platform Events, Flows, and Apex — the same pattern used by CSAA/AAA
for their auto insurance lead management.

---

## Insurance Domain Primer

If you're new to insurance, here are the key terms used throughout this kit:

### The Insurance Customer Lifecycle

```
┌─────────┐    ┌─────────┐    ┌──────────┐    ┌──────────┐    ┌────────────┐
│  INQUIRY │───▶│  QUOTE  │───▶│   BIND   │───▶│  POLICY  │───▶│   RENEWAL  │
│          │    │         │    │          │    │          │    │            │
│ Customer │    │ Premium │    │ Customer │    │ Policy   │    │ Annual     │
│ asks for │    │ is      │    │ says     │    │ is       │    │ renewal    │
│ pricing  │    │ calculated│   │ "yes,    │    │ active   │    │ cycle      │
│          │    │         │    │ I'll buy"│    │          │    │            │
└─────────┘    └─────────┘    └──────────┘    └──────────┘    └────────────┘
```

| Term | What It Means | Salesforce Record |
|------|---------------|-------------------|
| **Inquiry/Lead** | Customer wants pricing but hasn't committed | Lead |
| **Quote** | A calculated price offer (e.g., "$150/month for 6 months") | Quote + QuoteLineItems |
| **Bind** | Customer accepted the quote — they're buying the policy | Lead (for agent to finalize paperwork) |
| **Policy** | The active insurance contract | InsurancePolicy (FSC object) |
| **Premium** | The price the customer pays (monthly or per-term) | Amount field on Quote |
| **Policy Term** | Duration of coverage (typically 6 or 12 months for auto) | Quote expiration / Opp close date |

### Why "Bind" Creates a Lead (Not an Opportunity)

This is counterintuitive — you'd think a purchase would be an Opportunity. But in insurance:
- **Bind = the customer already bought it** on the website
- The agent's job is NOT to sell — it's to verify paperwork, ensure compliance, issue the policy
- A Lead represents "work for an agent to do" — which is exactly what bind processing is
- An Opportunity represents "something we're still trying to sell" — that's the quoted status

### Why "Quoted" Creates an Opportunity

- The customer got a price but didn't buy yet
- The agent needs to follow up, answer questions, close the sale
- This IS a sales opportunity — hence Opportunity + Quote in Salesforce

### Key Insurance Concepts in This Integration

| Concept | Explanation | Example |
|---------|-------------|---------|
| **Club Code** | AAA is organized by regional clubs. Each club (e.g., CSAA = Northern California) has its own agents. The club code routes leads to the right team. | `023` = Northern California |
| **Product of Interest** | What type of insurance the customer wants. Multiple products = "bundled quote." | Auto, Property, Umbrella |
| **Bundled Quote** | Customer wants multiple insurance types together (usually for a discount). Creates multiple Quote records under one Opportunity. | Auto + Homeowners together |
| **Quote Reference Number** | External system's unique ID for the quote. Used to link back to the quoting engine. | `QC0012456789` |
| **CSAA Rating** | Risk classification of the customer (affects pricing). | "2-Medium" |
| **Lead Source** | Marketing channel that brought the customer. Important for ROI tracking. | "Media Alpha", "Google Ads" |

---

## Platform Events — A Complete Primer

If you've never worked with Platform Events, read this section carefully.

### What IS a Platform Event?

Think of it as a **message bus inside Salesforce**. It's similar to Apache Kafka, RabbitMQ,
or AWS SNS/SQS — but native to the Salesforce platform.

**Analogy:** Imagine a bulletin board in an office:
- Anyone can **post a note** (publish an event)
- Anyone who's watching the board **gets notified** (subscribe to events)
- The poster doesn't need to know who's reading (decoupled)
- Notes stay on the board for 72 hours in case someone missed it (replay)

### Platform Event vs. Custom Object

| Aspect | Custom Object | Platform Event |
|--------|---------------|----------------|
| **Storage** | Persisted forever in database | Temporary (72-hour retention) |
| **Purpose** | Store data | Deliver messages |
| **Query** | SOQL queryable anytime | Cannot be queried after delivery |
| **Triggers** | Before/After Insert/Update/Delete | After publish only |
| **Transactions** | Same transaction as caller | Separate transaction (async) |
| **Governor Limits** | Shared with your code | Separate limits |
| **Suffix** | `__c` | `__e` |

### Platform Event vs. REST API (Why Not Just Call Salesforce Directly?)

| REST API Approach | Platform Event Approach |
|-------------------|------------------------|
| External system calls Salesforce REST endpoint | External system publishes event |
| Synchronous — caller waits for response | Asynchronous — fire and forget |
| Timeout risk (Salesforce has 120s limit) | No timeout — event is queued |
| Caller needs Salesforce auth tokens | Caller just needs publish permission |
| If processing fails, caller must retry | If processing fails, event can be replayed |
| Burst of 1000 calls = 1000 API calls consumed | Burst of 1000 events = 1 API call (batch publish) |
| Complex processing can timeout | Flow processes at its own pace |

**Bottom line:** For lead ingestion where processing is complex (account matching, scoring,
multiple record creation), Platform Events are far more reliable than synchronous REST.

### How Platform Event Publishing Works

```
External System                    Salesforce
─────────────────                 ─────────────────────────────────
                                  
POST /services/data/v62.0/        ┌─────────────────────────┐
  sobjects/                       │  Event Bus              │
  Auto_Quote_Lead_Event__e   ───▶ │  (stores event message) │
                                  └──────────┬──────────────┘
Body: {                                      │
  "First_Name__c": "John",                   │ Delivers to all subscribers
  "Last_Name__c": "Smith",                   │
  "Quote_Status__c": "quoted",               ▼
  ...                             ┌─────────────────────────┐
}                                 │  Platform Event Flow     │
                                  │  (Auto-triggered)        │
Response: 201 Created             │  - Processes payload     │
(that's it — fire & forget)       │  - Creates records       │
                                  └─────────────────────────┘
```

### How Platform Event Subscription Works (Flow)

In Salesforce, you subscribe to Platform Events by creating a **Platform Event-Triggered Flow**:

1. Go to Setup → Flows → New Flow → Platform Event-Triggered Flow
2. Select the event: `Auto_Quote_Lead_Event__e`
3. The flow **automatically fires** every time an event is published
4. Inside the flow, `$Record` refers to the event message (just like record-triggered flows)
5. The flow runs in its **own transaction** — separate from the publisher

**Key constraint:** Platform Event Flows process events in **batches of up to 2000**. If your
flow calls Apex, your Apex must handle `List<>` inputs (bulkification).

### Event Replay — The Safety Net

If your flow fails (a bug, governor limit, etc.):
1. The event stays on the bus for 72 hours
2. You can fix the flow
3. Go to Setup → Platform Events → Your Event → Subscribers → Resume from failure point
4. All missed events replay through the fixed flow

This is why Platform Events are **safer than REST** for critical integrations — data is never lost.

---

## System Design

### L1 — High-Level System Context Diagram

This shows every system involved and how data flows between them. Read left-to-right.

```
┌────────────────────────────────────────────────────────────────────────────────────────────┐
│                                    INTERNET / EXTERNAL                                      │
│                                                                                            │
│  ┌───────────────────┐         ┌───────────────────────────┐                               │
│  │   AAA WEBSITE     │         │   MIDDLEWARE (WSO2/Mule)   │                               │
│  │                   │         │                           │                               │
│  │  • Quote Form     │  JSON   │  • Receives payload       │                               │
│  │  • Vehicle Info   │────────▶│  • Calls Contact Match API│                               │
│  │  • Driver Info    │         │  • Enriches with          │                               │
│  │  • Coverage Opts  │         │    "knownCustomer" node   │                               │
│  │                   │         │  • Publishes PE to SF     │                               │
│  └───────────────────┘         └─────────────┬─────────────┘                               │
│                                               │                                            │
│         ┌────────────────────┐                │  REST API: POST                            │
│         │  QUOTE ENGINE      │                │  /sobjects/Auto_Quote_Lead_Event__e         │
│         │  (Exigen/Guidewire)│                │                                            │
│         │                    │                │  Fire & Forget                              │
│         │  • Calculates      │                │  (Response: 201 Created)                    │
│         │    premium         │                │                                            │
│         │  • Risk rating     │                │                                            │
│         │  • Quote ref #     │                │                                            │
│         └────────────────────┘                │                                            │
│                                               │                                            │
└───────────────────────────────────────────────┼────────────────────────────────────────────┘
                                                │
════════════════════════════════════════════════════════════════════════════════════════════════
                                                │
┌───────────────────────────────────────────────┼────────────────────────────────────────────┐
│                              SALESFORCE ORG    │                                            │
│                                               ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────┐                       │
│  │                     PLATFORM EVENT BUS                           │                       │
│  │                                                                 │                       │
│  │   Auto_Quote_Lead_Event__e                                      │                       │
│  │   ┌─────────────────────────────────────────────────────────┐   │                       │
│  │   │ First_Name, Last_Name, Email, Phone, Address fields     │   │                       │
│  │   │ Quote_Status, Quote_Reference, Premium, Policy_Term     │   │                       │
│  │   │ Product_Code, Club_Code, Lead_Source, Payload_JSON      │   │                       │
│  │   └─────────────────────────────────────────────────────────┘   │                       │
│  │                                                                 │                       │
│  │   Retention: 72 hours │ Replay: Yes │ Type: High Volume         │                       │
│  └──────────────────────────────┬──────────────────────────────────┘                       │
│                                 │                                                          │
│                                 │ Auto-delivers to subscribers                             │
│                                 ▼                                                          │
│  ┌──────────────────────────────────────────────────────────────────────┐                  │
│  │              PLATFORM EVENT-TRIGGERED FLOW                            │                  │
│  │              "Auto Quote Lead Ingestion Flow"                         │                  │
│  │                                                                      │                  │
│  │  ┌────────────┐    ┌──────────────┐    ┌──────────────────────────┐  │                  │
│  │  │  TRIGGER   │───▶│  APEX ACTION │───▶│  DECISION + RECORD       │  │                  │
│  │  │  (on PE)   │    │  (Processor) │    │  CREATION                │  │                  │
│  │  └────────────┘    └──────────────┘    └──────────────────────────┘  │                  │
│  └──────────────────────────────────────────────────────────────────────┘                  │
│                                 │                                                          │
│                                 │ Creates/Updates                                          │
│                                 ▼                                                          │
│  ┌──────────────────────────────────────────────────────────────────────┐                  │
│  │                    SALESFORCE DATA LAYER                              │                  │
│  │                                                                      │                  │
│  │  ┌──────────┐  ┌──────────────┐  ┌─────────────┐  ┌──────────────┐  │                  │
│  │  │   LEAD   │  │PERSON ACCOUNT│  │ OPPORTUNITY │  │    QUOTE     │  │                  │
│  │  │          │  │  (Customer)  │  │             │  │              │  │                  │
│  │  │ • Name   │  │ • Name      │  │ • Name      │  │ • Reference# │  │                  │
│  │  │ • Email  │  │ • Email     │  │ • Amount    │  │ • Premium    │  │                  │
│  │  │ • Phone  │  │ • Phone     │  │ • Stage     │  │ • Status     │  │                  │
│  │  │ • Status │  │ • Address   │  │ • CloseDate │  │ • Expiry     │  │                  │
│  │  │ • Source │  │ • RecType   │  │ • AccountId │  │ • OppId      │  │                  │
│  │  └──────────┘  └──────────────┘  └─────────────┘  └──────────────┘  │                  │
│  │                                                                      │                  │
│  │  ┌──────────────┐  ┌──────────────┐                                  │                  │
│  │  │  PRODUCT2    │  │ PRICEBOOK    │                                  │                  │
│  │  │              │  │   ENTRY      │                                  │                  │
│  │  │ • Auto Ins   │  │ • $150/mo    │                                  │                  │
│  │  │ • Prop Ins   │  │ • $125/mo    │                                  │                  │
│  │  └──────────────┘  └──────────────┘                                  │                  │
│  └──────────────────────────────────────────────────────────────────────┘                  │
│                                                                                            │
│  ┌──────────────────────────────────────────────────────────────────────┐                  │
│  │                    APEX CLASSES (Processing Layer)                    │                  │
│  │                                                                      │                  │
│  │  AutoQuoteLeadProcessor          AutoQuoteLeadRequest                │                  │
│  │  ┌────────────────────────┐      ┌────────────────────────┐         │                  │
│  │  │ @InvocableMethod       │      │ @InvocableVariable     │         │                  │
│  │  │ • Account matching     │◀─────│ • firstName            │         │                  │
│  │  │   (SOQL by email)      │      │ • lastName             │         │                  │
│  │  │ • Bind/quoted check    │      │ • email, phone         │         │                  │
│  │  │ • Bundled detection    │      │ • quoteStatus          │         │                  │
│  │  │ • RecordType lookup    │      │ • premium, policyTerm  │         │                  │
│  │  └───────────┬────────────┘      └────────────────────────┘         │                  │
│  │              │                                                       │                  │
│  │              │ Returns                                               │                  │
│  │              ▼                                                       │                  │
│  │  AutoQuoteLeadResponse                                               │                  │
│  │  ┌────────────────────────┐                                          │                  │
│  │  │ @InvocableVariable     │                                          │                  │
│  │  │ • matchedAccountId     │                                          │                  │
│  │  │ • isExistingCustomer   │                                          │                  │
│  │  │ • isBindStatus         │                                          │                  │
│  │  │ • isBundledQuote       │                                          │                  │
│  │  │ • personAcctRTId       │                                          │                  │
│  │  └────────────────────────┘                                          │                  │
│  └──────────────────────────────────────────────────────────────────────┘                  │
│                                                                                            │
└────────────────────────────────────────────────────────────────────────────────────────────┘
```

### L2 — Component Interaction Diagram

This shows the runtime sequence — what calls what, in what order:

```
 External          Middleware           Salesforce        Event         Flow          Apex
 System            (WSO2)               Event Bus        Flow        (Decisions)    Processor
    │                  │                    │              │              │              │
    │  1. Submit       │                    │              │              │              │
    │  quote form      │                    │              │              │              │
    │─────────────────▶│                    │              │              │              │
    │                  │                    │              │              │              │
    │                  │ 2. Enrich payload  │              │              │              │
    │                  │    (contact match) │              │              │              │
    │                  │──────────────────▶ │              │              │              │
    │                  │ ◀──── match result │              │              │              │
    │                  │                    │              │              │              │
    │                  │ 3. Publish PE      │              │              │              │
    │                  │───────────────────▶│              │              │              │
    │                  │    (201 Created)   │              │              │              │
    │                  │◀──────────────────│              │              │              │
    │  (done)          │  (done)           │              │              │              │
    │                  │                    │ 4. Deliver   │              │              │
    │                  │                    │──────────────▶              │              │
    │                  │                    │              │              │              │
    │                  │                    │              │ 5. Call Apex │              │
    │                  │                    │              │─────────────────────────────▶
    │                  │                    │              │              │              │
    │                  │                    │              │              │    6. Match  │
    │                  │                    │              │              │    accounts  │
    │                  │                    │              │              │    (SOQL)    │
    │                  │                    │              │              │              │
    │                  │                    │              │ 7. Response  │              │
    │                  │                    │              │◀─────────────────────────────
    │                  │                    │              │              │              │
    │                  │                    │              │ 8. Decision  │              │
    │                  │                    │              │─────────────▶│              │
    │                  │                    │              │              │              │
    │                  │                    │              │  9. Create   │              │
    │                  │                    │              │  records     │              │
    │                  │                    │              │◀─────────────│              │
    │                  │                    │              │              │              │
```

---

## Process Flow (Decision Logic)

### Main Flow — What Happens to Each Incoming Event

This is the detailed decision tree that the Platform Event Flow follows.
Each diamond (◇) is a decision point. Each box is an action.

```
                            ┌─────────────────────────┐
                            │   PLATFORM EVENT        │
                            │   RECEIVED              │
                            │                         │
                            │   Auto_Quote_Lead_      │
                            │   Event__e published    │
                            └────────────┬────────────┘
                                         │
                                         ▼
                            ┌─────────────────────────┐
                            │   CALL APEX PROCESSOR   │
                            │                         │
                            │   • Parse all fields    │
                            │   • Match by email      │
                            │   • Set flags:          │
                            │     - isBindStatus      │
                            │     - isExistingCustomer│
                            │     - isBundledQuote    │
                            └────────────┬────────────┘
                                         │
                                         ▼
                            ┌ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┐
                                                      
                            │   ◇ QUOTE STATUS?       │
                                                      
                            └ ─ ─ ─ ─┬─ ─ ─ ─ ┬─ ─ ─ ┘
                                     │         │
                    ─────────────────┘         └─────────────────
                    │                                           │
                    ▼                                           ▼
    ┌───────────────────────────┐               ┌───────────────────────────┐
    │  STATUS = "bind" or       │               │  STATUS = "quoted" or     │
    │          "abandoned"      │               │           any other       │
    │                           │               │                           │
    │  Customer already bought  │               │  Customer is shopping     │
    │  or walked away — agent   │               │  — this is a sales        │
    │  needs to follow up       │               │  opportunity              │
    └─────────────┬─────────────┘               └─────────────┬─────────────┘
                  │                                           │
                  ▼                                           ▼
    ┌───────────────────────────┐               ┌ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┐
    │   CREATE LEAD             │                                         
    │                           │               │  ◇ EXISTING CUSTOMER?   │
    │   • FirstName, LastName   │                                         
    │   • Email, Phone          │               └ ─ ─ ─ ─┬─ ─ ─ ─ ┬─ ─ ─ ┘
    │   • Address fields        │                        │         │
    │   • LeadSource            │               ─────────┘         └─────────
    │   • Status = "New"        │               │                           │
    │   • Description = Ref#    │               ▼                           ▼
    │                           │  ┌────────────────────────┐  ┌────────────────────────┐
    │   → Agent works this lead │  │  YES — Customer found  │  │  NO — New customer     │
    │     for bind processing   │  │                        │  │                        │
    │     or re-engagement      │  │  Use matchedAccountId  │  │  CREATE PERSON ACCOUNT │
    └───────────────────────────┘  │  from Apex response    │  │                        │
                                   │                        │  │  • FirstName, LastName  │
                                   └───────────┬────────────┘  │  • PersonEmail          │
                                               │               │  • PersonMobilePhone    │
                                               │               │  • RecordType =         │
                                               │               │    Person Account       │
                                               │               └───────────┬────────────┘
                                               │                           │
                                               └──────────┬────────────────┘
                                                          │
                                                          │  (Account ID now available
                                                          │   — either found or just created)
                                                          │
                                                          ▼
                                            ┌───────────────────────────┐
                                            │   CREATE OPPORTUNITY      │
                                            │                           │
                                            │   • Name = "FirstName     │
                                            │     LastName - Auto Quote  │
                                            │     - Date"               │
                                            │   • Stage = "Prospecting" │
                                            │   • Amount = Premium      │
                                            │   • CloseDate = Today+45  │
                                            │   • AccountId = matched   │
                                            │     or newly created      │
                                            │   • LeadSource            │
                                            └─────────────┬─────────────┘
                                                          │
                                                          ▼
                                            ┌ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┐
                                                                      
                                            │  ◇ BUNDLED QUOTE?       │
                                               (Product_Code has ";")  
                                            └ ─ ─ ─ ─┬─ ─ ─ ─ ┬─ ─ ─ ┘
                                                     │         │
                                    ─────────────────┘         └───────────────
                                    │                                         │
                                    ▼                                         ▼
                    ┌───────────────────────────┐          ┌───────────────────────────┐
                    │  SINGLE QUOTE             │          │  BUNDLED QUOTES            │
                    │                           │          │                           │
                    │  CREATE 1 QUOTE           │          │  CREATE 2 QUOTES          │
                    │  • Name = QuoteRef#       │          │  (one per product code)   │
                    │  • OpportunityId          │          │                           │
                    │  • Status = "Draft"       │          │  Quote 1: Auto            │
                    │  • ExpirationDate         │          │  Quote 2: Property        │
                    │                           │          │                           │
                    │  CREATE 1 QUOTE LINE ITEM │          │  Flag Opportunity:        │
                    │  • Product = Auto Ins     │          │  "Bundled = true"         │
                    │  • UnitPrice = Premium    │          │                           │
                    │  • Quantity = 1           │          │  CREATE QUOTE LINE ITEMS  │
                    │                           │          │  for each quote           │
                    └───────────────────────────┘          └───────────────────────────┘
```

### Account Matching Sub-Process

This is what happens inside the Apex processor when it tries to find an existing customer:

```
                    ┌─────────────────────────────────┐
                    │  INCOMING EVENT DATA             │
                    │  • Email: john.smith@example.com │
                    │  • FirstName: John               │
                    │  • LastName: Smith               │
                    │  • Phone: 5551234567             │
                    └───────────────┬─────────────────┘
                                    │
                                    ▼
                    ┌ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┐
                      ◇ PRODUCTION: Was "knownCustomer"
                    │   node provided by middleware?    │
                    └ ─ ─ ─ ─ ─ ─ ─┬─ ─ ─ ─ ─┬─ ─ ─ ┘
                                    │          │
                              YES   │          │  NO (or learning kit)
                                    ▼          ▼
                    ┌──────────────────┐  ┌──────────────────────┐
                    │ Read MatchCount   │  │ SOQL MATCHING        │
                    │ from knownCustomer│  │                      │
                    │                  │  │ Query 1: Match by     │
                    │ MatchCount = 1?  │  │ PersonEmail           │
                    │ → Use that acct  │  │                      │
                    │                  │  │ Query 2: Match by     │
                    │ MatchCount = 0?  │  │ FirstName + LastName  │
                    │ → No match       │  │                      │
                    │                  │  │ Query 3: Match by     │
                    │ MatchCount > 1?  │  │ Phone                 │
                    │ → Ambiguous      │  │                      │
                    └────────┬─────────┘  └──────────┬───────────┘
                             │                       │
                             └───────────┬───────────┘
                                         │
                                         ▼
                    ┌ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┐
                      ◇ MATCH FOUND?                   
                    └ ─ ─ ─ ─ ─ ─ ─┬─ ─ ─ ─ ─┬─ ─ ─ ┘
                                    │          │
                              YES   │          │ NO
                                    ▼          ▼
                    ┌──────────────────┐  ┌──────────────────┐
                    │ isExistingCustomer│  │ isExistingCustomer│
                    │ = TRUE           │  │ = FALSE           │
                    │                  │  │                   │
                    │ matchedAccountId  │  │ matchedAccountId  │
                    │ = found Account   │  │ = NULL            │
                    │                  │  │                   │
                    │ (Flow will use   │  │ (Flow will CREATE │
                    │  this account)   │  │  new Person Acct) │
                    └──────────────────┘  └──────────────────┘
```

### Post-Ingestion: What Agents See

After the flow creates records, here's what appears in the agent's Salesforce experience:

```
┌─────────────────────────────────────────────────────────────────────┐
│  AGENT'S VIEW (after lead ingestion)                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  IF BIND STATUS → Agent sees in LEAD QUEUE:                         │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  Lead: Sarah Johnson                                         │    │
│  │  Status: New                                                 │    │
│  │  Source: AAA Website                                         │    │
│  │  Description: Quote Ref QC0098765432                         │    │
│  │                                                              │    │
│  │  Agent's job: Verify paperwork, issue policy in EPIC system  │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
│  IF QUOTED STATUS → Agent sees in OPPORTUNITY PIPELINE:             │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  Opportunity: John Smith - Auto Quote - Jun 18, 2026         │    │
│  │  Stage: Prospecting                                          │    │
│  │  Amount: $150.75                                             │    │
│  │  Close Date: Aug 2, 2026                                     │    │
│  │  Account: John Smith (Person Account)                        │    │
│  │                                                              │    │
│  │  └─ Quote: QC0012456789                                      │    │
│  │     Status: Draft                                            │    │
│  │     └─ Quote Line Item: Auto Insurance — $150.75             │    │
│  │                                                              │    │
│  │  Agent's job: Call customer, answer questions, close the sale │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Architecture Deep Dive

### The Full Integration Flow (Step by Step)

Here's what happens when a customer submits an auto quote on the AAA website:

```
STEP 1: Customer fills form on AAA website
        ↓
STEP 2: Website calls CSAA's quote engine (Exigen)
        - Calculates premium based on: vehicle, driving history, location, coverage
        - Assigns quote reference number (QC0012456789)
        - Determines quote status (quoted, bind, abandoned)
        ↓
STEP 3: Quote engine sends payload to Middleware (WSO2)
        - Full JSON payload with all customer + quote details
        ↓
STEP 4: Middleware performs DATA ENRICHMENT
        - Calls Salesforce Contact Matching API
        - Asks: "Does this customer already exist?"
        - Gets back: MatchCount (0, 1, or many) + existing customer data
        - Adds "knownCustomer" node to the payload
        ↓
STEP 5: Middleware PUBLISHES Platform Event to Salesforce
        - POST to /services/data/v62.0/sobjects/Auto_Quote_Lead_Event__e
        - Flattens key fields into event fields
        - Puts full JSON in Payload_JSON__c field
        - Gets back 201 Created → done (fire and forget)
        ↓
STEP 6: Salesforce EVENT BUS receives the event
        - Stores it
        - Notifies all subscribers
        ↓
STEP 7: Platform Event Flow TRIGGERS
        - Receives $Record (the event)
        - Calls Invocable Apex: AutoQuoteLeadProcessor
        ↓
STEP 8: Apex PROCESSES the event
        - Reads all fields from the event
        - Performs account matching (SOQL by email)
        - Determines: Is this bind/abandoned? Is this bundled?
        - Returns structured response back to Flow
        ↓
STEP 9: Flow DECIDES what to create
        - IF bind/abandoned → Create Lead (for agent paperwork)
        - IF quoted (and customer exists) → Create Opportunity + Quote
        - IF quoted (and NO customer exists) → Create Person Account FIRST, then Opp + Quote
        ↓
STEP 10: Records are CREATED in Salesforce
         - Agent sees new Lead or Opportunity in their queue
         - Follow-up process begins
```

### Why Flow + Apex (Not Just One or the Other)?

**Why not pure Apex (trigger on PE)?**
- Admins can't see or modify trigger logic without developer help
- Flow is visible in Setup → Flows → anyone can trace the logic
- Business rules change often (e.g., "now route Club 023 differently") — easier in Flow

**Why not pure Flow (no Apex)?**
- Flow can't parse nested JSON arrays (vehicles, drivers, quotes)
- Flow can't perform complex SOQL-based matching across multiple fields
- Flow variables can't handle dynamic typing well
- Governor limit management is easier in Apex

**The hybrid pattern (used here):**
- **Flow** handles orchestration (decisions, record creation, routing)
- **Apex** handles data processing (JSON parsing, matching, transformation)
- They communicate via `@InvocableMethod` and `@InvocableVariable` wrappers

---

## The JSON Payload — Explained Field by Field

This is the actual payload structure sent by the external system. Understanding each field
helps you understand what data matters in insurance lead management.

```json
{
  "metaData": {
    "campaignId": "CAMP123456",        // Marketing campaign that generated this lead
    "marketingnetwork": "Media Alpha Net +"  // Ad network (for ROI attribution)
  },
  "Club_code": "023",                  // AAA regional club (routes to correct agent team)
                                       //   023 = CSAA (Northern California)
                                       //   015 = CCAA (Southern California)
  "leadInfo": {
    "productOfInterests": [            // What they want to buy (can be multiple = bundled)
      { "productFamilyCode": "Auto" },
      { "productFamilyCode": "Property" }
    ],
    "primaryContactInfo": {
      "name": {
        "firstName": "John",
        "lastName": "Smith",
        "middleName": "A"
      },
      "emails": [                      // Array because customer may have multiple
        { "emailID": "john.smith@example.com" }
      ],
      "phones": [
        { "phoneNumber": "5551234567" }
      ],
      "addresses": [                   // Full address is needed for:
        {                              //   1. Insurance rating (risk varies by ZIP)
          "addressLine1": "123 Main Street",  // 2. State determines regulations
          "addressLine2": "Apt 101",          // 3. Routing to local agent
          "city": "Phoenix",
          "stateProvCd": "AZ",         // State code — critical for insurance
          "postalCode": "85001",       //   (different states = different requirements)
          "countryCode": "US",
          "addressTypeCode": "Home",   // Home vs. Mailing vs. Business
          "county": "Maricopa"         // County-level rating in some states
        }
      ],
      "gender": "Male",               // Rating factor for auto insurance
      "maritalStatusCode": "Married",  // Rating factor (married = lower risk statistically)
      "isHomeOwner": true,             // Cross-sell signal (homeowner = offer bundled policy)
      "residenceType": "House"         // Rating factor
    },
    "leadIdentifier": "LEAD-78910",    // External system's lead tracking ID
    "customerId": "CUST-123456"        // If customer is already known to the enterprise
  },
  "quotes": [                          // The actual quote(s) calculated by the engine
    {
      "effectiveDate": "2024-09-15",   // When coverage would start
      "quoteReferenceNumber": "QC0012456789",  // Unique ID in the quoting engine
      "quoteStatus": "bind",           // THIS FIELD DRIVES THE ENTIRE FLOW:
                                       //   "quoted" = customer received price, hasn't decided
                                       //   "bind"   = customer accepted, wants to buy
                                       //   "abandoned" = customer started but left
      "policyTerm": 12,               // Coverage duration in months (6 or 12 typical)
      "premium": 150.75,              // Price per month (or per term)
      "membershipInfo": [
        { "membershipNumber": "MEM-5556789" }  // AAA membership (loyalty discount)
      ],
      "tier": "C-Aspiring",           // Customer value tier (affects priority)
      "urgency": 70,                  // Score 0-100 (higher = contact sooner)
      "csaarating": "2-Medium",       // Risk classification
      "vehicles": [                   // Vehicle details (for auto insurance rating)
        {
          "vehicleId": "VEH-123456",
          "vehicleUsageCd": "Personal" // Personal vs. Commercial vs. Rideshare
        }
      ],
      "drivers": [                    // Driver details (for auto insurance rating)
        {
          "driverId": "DRV-98765",
          "maritalStatusCode": "Married",
          "relationshipCode": "Primary",  // Primary insured vs. spouse vs. child
          "gender": "Male"
        }
      ]
    }
  ]
}
```

### How This Payload Maps to the Platform Event

The middleware **flattens** the nested JSON into Platform Event fields:

| JSON Path | Platform Event Field | Why Flattened? |
|-----------|---------------------|----------------|
| `leadInfo.primaryContactInfo.name.firstName` | `First_Name__c` | Flow needs direct access |
| `leadInfo.primaryContactInfo.name.lastName` | `Last_Name__c` | Flow needs direct access |
| `leadInfo.primaryContactInfo.emails[0].emailID` | `Email__c` | Used for account matching |
| `leadInfo.primaryContactInfo.phones[0].phoneNumber` | `Phone__c` | Lead/Account field |
| `leadInfo.primaryContactInfo.addresses[0].addressLine1` | `Street__c` | Lead address |
| `leadInfo.primaryContactInfo.addresses[0].city` | `City__c` | Lead address |
| `leadInfo.primaryContactInfo.addresses[0].stateProvCd` | `State_Code__c` | Lead address |
| `leadInfo.primaryContactInfo.addresses[0].postalCode` | `Postal_Code__c` | Lead address |
| `leadInfo.productOfInterests[*].productFamilyCode` | `Product_Code__c` | Semicolon-joined: "Auto;Property" |
| `quotes[0].quoteReferenceNumber` | `Quote_Reference__c` | External reference |
| `quotes[0].quoteStatus` | `Quote_Status__c` | **Drives the decision logic** |
| `quotes[0].premium` | `Premium__c` | Quote/Opp amount |
| `quotes[0].policyTerm` | `Policy_Term__c` | Close date calculation |
| `Club_code` | `Club_Code__c` | Agent routing |
| `metaData.marketingnetwork` | `Lead_Source__c` | Attribution |
| *(entire JSON)* | `Payload_JSON__c` | For complex processing (vehicles, drivers) |

**Design insight:** We flatten the "hot path" fields (name, email, status) for Flow access,
but keep the full JSON for Apex processing of nested arrays. This avoids needing 50+ PE fields.

---

## How To Build This Yourself (Step by Step)

If you were building this pattern from scratch, here's the order of decisions:

### Step 1: Define the Platform Event

1. Go to Setup → Platform Events → New Platform Event
2. Name it based on the integration: `Auto_Quote_Lead_Event__e`
3. Choose **High Volume** (supports millions of events/day) vs Standard (limited)
4. Add fields for every piece of data your Flow needs direct access to
5. Add a `Payload_JSON__c` LongTextArea for everything else

**Rule of thumb:** Flatten fields that the Flow uses in decisions or record creation.
Leave complex/nested data in the JSON payload for Apex processing.

### Step 2: Build the Apex Processor

1. Create wrapper classes (`Request` and `Response`) with `@InvocableVariable`
2. Create the processor class with `@InvocableMethod`
3. The processor should:
   - Parse the event fields
   - Perform account matching (SOQL)
   - Set boolean flags for Flow decisions (`isExistingCustomer`, `isBindStatus`)
   - Return everything the Flow needs in the response wrapper

**Why @InvocableMethod?** It's the bridge between Flow and Apex. Flow can call it as an
Action element and receive structured output.

### Step 3: Build the Platform Event Flow

1. Setup → Flows → New → Platform Event-Triggered Flow
2. Select: `Auto_Quote_Lead_Event__e`
3. First element: **Action** → Call your Apex processor
4. Map `$Record.First_Name__c` etc. to the Apex input parameters
5. Add **Decision** elements based on the Apex response (`isBindStatus`, `isExistingCustomer`)
6. Add **Create Records** elements for each path (Lead, Account, Opportunity, Quote)

### Step 4: Set Up Products (for Quote Line Items)

1. Create Product2 records for each insurance type (Auto, Property, etc.)
2. Add to Standard Price Book
3. When creating Quotes, add QuoteLineItems mapped to these products

### Step 5: Test with Published Events

You can test without the external system by publishing events via Anonymous Apex:
```apex
Auto_Quote_Lead_Event__e testEvent = new Auto_Quote_Lead_Event__e(
    First_Name__c = 'Test',
    Last_Name__c = 'User',
    Email__c = 'test@example.com',
    Quote_Status__c = 'quoted',
    Premium__c = 100.00
);
EventBus.publish(testEvent);
```

---

## Licensing & Prerequisites

### Required Salesforce Editions/Licenses

| Component | License Required | Why | Cost Impact |
|-----------|-----------------|-----|-------------|
| Person Accounts | FSC, or B2C Commerce, or enable on Enterprise+ | Policyholders are individuals, not business accounts | Included with FSC |
| Platform Events | Enterprise Edition+ | The integration messaging backbone | Included (volume limits vary by edition) |
| Flow Builder | Enterprise Edition+ | Orchestration engine | Included |
| Lead Management | Any Sales Cloud license | Standard Lead object and conversion | Included with Sales Cloud |
| Quotes | Sales Cloud | Must be explicitly enabled in Setup | Included but disabled by default |
| Products & Price Books | Sales Cloud | Product catalog for insurance lines | Included |

### Edition-Specific Platform Event Limits

| Edition | Daily Standard Volume Events | Daily High Volume Events |
|---------|------------------------------|--------------------------|
| Enterprise | 250,000 | 10,000,000 |
| Unlimited | 500,000 | 50,000,000 |
| Developer | 25,000 | 25,000 |

**For this demo:** We publish 3 events. You won't hit limits.

### Prerequisites Checklist — Manual Steps (BEFORE Deployment)

These must be completed manually in Setup before running the deployment skill.
They cannot be automated — each requires UI configuration or org-level settings.

| # | Manual Step | Where in Setup | Why It Can't Be Automated | How to Verify |
|---|-------------|----------------|---------------------------|---------------|
| 1 | **Enable Person Accounts** | Setup → Account Settings → Enable Person Accounts | Irreversible org change; requires SF Support on existing orgs | `Schema.SObjectType.Account.fields.getMap().containsKey('IsPersonAccount')` returns true |
| 2 | **Enable Quotes** | Setup → Quote Settings → Enable | Org-level toggle, not deployable via metadata | Quote object appears in Schema.getGlobalDescribe() |
| 3 | **Verify Person Account Record Type** | Setup → Object Manager → Account → Record Types | Must be active and assigned to user profile | At least one RT with `isPersonType() = true` |
| 4 | **Verify Lead Status "New" exists** | Setup → Object Manager → Lead → Fields → Status | Picklist value — may have been removed on customized orgs | Flow will fail on Create Lead if missing |
| 5 | **Verify Opp Stage "Prospecting" exists** | Setup → Object Manager → Opportunity → Fields → Stage | Picklist value — may have been renamed | Flow will fail on Create Opportunity if missing |
| 6 | **Standard Price Book exists** | App Launcher → Products → Price Books | Usually auto-created, but can be deactivated | SOQL: `SELECT Id FROM Pricebook2 WHERE IsStandard = true` |
| 7 | **User has Sales Cloud license** | Setup → Users → User Detail | License assignment is manual | User can create Lead, Opportunity, Quote |
| 8 | **User has "Customize Application"** | Profile or Permission Set | Required to deploy Apex and Platform Events | Deploy command succeeds |

**For Scratch Orgs:** Add these to your `project-scratch-def.json`:
```json
{
  "orgName": "Lead Ingestion Demo",
  "edition": "Enterprise",
  "features": ["PersonAccounts", "LightningExperience"],
  "settings": {
    "quoteSettings": { "enableQuote": true }
  }
}
```

---

## Key Design Decisions Explained

### 1. Why Platform Event (Not Change Data Capture or Streaming API)?

| Option | Verdict | Why |
|--------|---------|-----|
| **Platform Event** | **CHOSEN** | External system publishes a custom message structure. We control the schema. |
| Change Data Capture | Rejected | CDC fires when SF records change — we need INBOUND data, not outbound notifications |
| Streaming API (PushTopics) | Rejected | Deprecated. Also notification-based, not inbound. |
| REST API + Apex trigger | Rejected | Synchronous timeout risk. Complex processing (matching) can exceed 120s. |
| Bulk API | Rejected | Batch-oriented, not real-time. Customer expects instant response. |

### 2. Why Person Account (Not Business Account + Contact)?

In B2C insurance:
- The **policyholder IS the customer** — there's no "company" in between
- Person Account = Account + Contact merged into one record
- Enables: PersonEmail, PersonMobilePhone, PersonMailingAddress
- Avoids: the awkward "what Account do I put this Contact under?" problem
- FSC requires it for most financial services features

### 3. Why the Flow Creates Records (Not Apex)?

The Apex processor does matching and parsing, but the Flow creates records because:
- **Visibility** — Admins can see what records are being created in Flow Builder
- **Flexibility** — Business rules change often ("add this field", "change the stage name")
- **Declarative first** — Salesforce best practice; Apex only when Flow can't do it
- **Error handling** — Flow fault paths are visual and easy to modify

### 4. Why a Separate "Enrichment" Step in Middleware?

In production, the middleware (WSO2) calls a Contact Matching API BEFORE publishing the event:
- This keeps expensive matching OUT of Salesforce governor limits
- The middleware adds a `knownCustomer` node with the match result
- Salesforce just reads the pre-computed match (fast, cheap)
- If matching fails in middleware, the event still publishes (with MatchCount = 0)

**In this learning kit:** We simplified — the Apex processor does matching directly via SOQL.
In production, you'd move this to a pre-processing layer.

---

## Simplifications from Production

This kit focuses on the core pattern. Here's what a production implementation adds:

| Production Feature | What It Does | Why Skipped |
|-------------------|--------------|-------------|
| WSO2 middleware | Pre-enriches payload with customer match | Adds external system dependency |
| DataWeave scripts | Transforms complex JSON to Quote sObjects | Requires DataWeave Runtime license |
| UnifiedProfile service | Enterprise-grade customer matching across systems | Complex custom Apex |
| Lead Scoring | AI-based priority scoring (urgency, tier, rating) | Requires Einstein or custom logic |
| Omni-Channel routing | Routes leads to available agents in real-time | Requires Omni-Channel setup |
| Cadence enrollment | Auto-enrolls leads in Sales Engagement cadences | Requires Sales Engagement license |
| Platform Event archival | Stores events in Big Objects for audit trail | Adds complexity |
| Cross-sell opportunities | Creates extra Opps for unsold product lines | Business logic beyond core pattern |
| 40+ custom fields on Lead | Tracks every insurance-specific data point | Clutters the learning example |
| Multiple platform events | CSAA, RFQ, ConnectSuite (3 event types) | One event type demonstrates the pattern |
| Error logging | FSL_Application_Log__c custom object | Custom error handling framework |
| Duplicate rule bypass | Database.DMLOptions for known duplicates | Edge case handling |

---

## Exploring After Deployment

Once deployed, here's what to look at in your org to understand the pattern:

### In Setup
1. **Platform Events** → `Auto_Quote_Lead_Event__e` — see the event definition
2. **Flows** → `Auto Quote Lead Ingestion Flow` — trace the logic visually
3. **Apex Classes** → `AutoQuoteLeadProcessor` — read the matching logic

### In the App
1. **Leads tab** — Find the Lead created by the bind scenario (Sarah Johnson)
2. **Accounts tab** — Find the Person Accounts created (John Smith, Michael Chen)
3. **Opportunities tab** — Find "John Smith - Auto Quote" and "Michael Chen - Auto Quote"
4. **Quotes** — Under each Opportunity, see the linked Quote with reference number

### Questions to Explore
- What happens if you publish an event with an email that matches an existing Person Account?
- What happens if `Quote_Status__c` is changed from "quoted" to "bind"?
- How would you add a new product type (e.g., "Umbrella" insurance)?
- How would you add lead scoring based on the premium amount?
- How would you route leads to different agents based on Club Code?
