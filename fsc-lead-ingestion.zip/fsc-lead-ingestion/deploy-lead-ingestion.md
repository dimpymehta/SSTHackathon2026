# FSC Lead Ingestion for Auto Quote — Deploy to Org

You are an interactive deployment assistant for the FSC Lead Ingestion Auto Quote pattern.
When this skill is invoked, follow the steps below in order. Do not skip steps. At each
decision point, wait for the user's response before continuing.

---

## On Invocation

Parse any arguments the user typed after the skill name:
- First argument → `ORG_ALIAS`

If the argument is missing, ask the user:

```
Missing argument — please provide:
1. Org alias (SFDX alias of the target org, e.g. mydevorg)
```

Once confirmed, proceed to **Manual Prerequisites** first.

---

## Manual Prerequisites (MUST be done BEFORE deployment)

Before running any automated steps, confirm the user has completed these manual setup items.
Present the checklist and **wait for the user to confirm each item**:

```
═══════════════════════════════════════════════════════════════
MANUAL PREREQUISITES — Complete these in Setup before proceeding
═══════════════════════════════════════════════════════════════

1. PERSON ACCOUNTS ENABLED
   Setup → Account Settings → "Enable Person Accounts"
   ⚠️  This is IRREVERSIBLE and requires Salesforce Support if not already enabled.
   If using a scratch org, add "PersonAccounts" to features in project-scratch-def.json.
   
   Status: [ ] Confirmed enabled

2. QUOTES ENABLED
   Setup → Quote Settings → Check "Enable Quotes"
   Then select a default Quote Template (or skip template selection).
   
   Status: [ ] Confirmed enabled

3. AUTHENTICATED TO ORG
   Run: sf org login web --alias <ORG_ALIAS>
   Or confirm you already have a valid session.
   
   Status: [ ] Confirmed authenticated

4. PERSON ACCOUNT RECORD TYPE EXISTS
   Setup → Record Types (on Account object)
   Confirm at least one Record Type with "Person Account" type is active.
   If using FSC, this is typically "Individual" or "Person Account".
   
   Status: [ ] Confirmed exists

5. LEAD STATUS "NEW" EXISTS
   Setup → Lead → Fields → Status
   Confirm "New" is in the picklist values.
   (Standard on most orgs — only an issue if heavily customized.)
   
   Status: [ ] Confirmed exists
   
6. OPPORTUNITY STAGE "PROSPECTING" EXISTS
   Setup → Opportunity → Fields → Stage
   Confirm "Prospecting" is in the picklist values.
   (Standard on most orgs — only an issue if heavily customized.)
   
   Status: [ ] Confirmed exists

═══════════════════════════════════════════════════════════════
```

Once the user confirms all items, proceed to Step 0.

---

## Step 0 — Authenticate & Pre-Flight

Tell the user: "Step 0 of 4 — Authenticating and running pre-flight checks."

### 0a. Verify authentication
Run:
```bash
sf org display --target-org <ORG_ALIAS>
```
- If it fails → tell the user to authenticate first with `sf org login web --alias <ORG_ALIAS>` and wait for them to confirm before continuing.
- If it succeeds → show the org name and instance URL from the output, then continue.

### 0b. Run pre-flight
Run:
```bash
sf apex run --file preflight_check.apex --target-org <ORG_ALIAS>
```
Parse the debug output:

- **Section 1 — Person Account enabled:** If FAIL → stop. Person Accounts must be enabled.
- **Section 2 — Lead object accessible:** If FAIL → stop. Sales Cloud license required.
- **Section 3 — Quote object enabled:** If FAIL → tell user to enable Quotes in Setup.
- **Section 4 — Platform Event limits:** If FAIL (>90% daily usage) → warn but continue.
- **Section 5 — Products exist:** INFO only — setup scripts will create them.

If **any blocking check FAILs** → display each failing check and its fix hint. Tell the user:
"Pre-flight failed — resolve the issues above before continuing." **STOP here.**

If all PASS → tell the user: "Pre-flight passed. Proceeding to Step 1."

---

## Step 1 — Deploy Metadata

Tell the user: "Step 1 of 4 — Deploying Platform Event, Apex classes, Flow, and Permission Set."

### 1a. Deploy metadata
Run from the `lead-ingestion/` directory:
```bash
sf project deploy start \
  --source-dir force-app/main/default/objects/Auto_Quote_Lead_Event__e \
  --source-dir force-app/main/default/classes \
  --source-dir force-app/main/default/flows \
  --source-dir force-app/main/default/permissionsets \
  --target-org <ORG_ALIAS>
```

- If it succeeds → continue.
- If it fails → show the error and stop.

### 1b. Assign permission set
```bash
sf org assign permset --name Auto_Quote_Lead_Ingestion_Access --target-org <ORG_ALIAS>
```

If it fails with "already assigned" → that's fine, continue.

---

## Step 2 — Setup Products & Seed Data

Tell the user: "Step 2 of 4 — Creating insurance products and a sample existing customer."

Run:
```bash
sf apex run --file setup_products.apex --target-org <ORG_ALIAS>
```

Parse the output:
- If it shows "Products created successfully" → continue.
- If it fails → show error and stop.

Then seed the existing customer:
```bash
sf apex run --file setup_existing_customer.apex --target-org <ORG_ALIAS>
```

---

## Step 3 — Simulate Lead Ingestion

Tell the user: "Step 3 of 4 — Publishing sample Platform Events to simulate lead ingestion."

Ask the user which scenario to run:
```
Which scenarios would you like to simulate?
1. New customer, quoted status (creates Account + Opportunity + Quote)
2. Existing customer, bind status (creates Lead)
3. Bundled quote — Auto + Property (creates Account + Opportunity + 2 Quotes)
4. All three scenarios [default]
```

Based on selection, run:
```bash
sf apex run --file simulate_ingestion.apex --target-org <ORG_ALIAS>
```

The script publishes platform events that trigger the flow. Wait 10 seconds for async processing.

---

## Step 4 — Verify

Tell the user: "Step 4 of 4 — Verifying records were created correctly."

Run:
```bash
sf apex run --file verify_install.apex --target-org <ORG_ALIAS>
```

Parse the output and display the results:

| Object | Expected | Actual | Status |
|--------|----------|--------|--------|
| Product2 | 2 | ? | ✓/✗ |
| Account (Person) | ≥2 | ? | ✓/✗ |
| Lead | ≥1 | ? | ✓/✗ |
| Opportunity | ≥2 | ? | ✓/✗ |
| Quote | ≥3 | ? | ✓/✗ |

If all pass → "Deployment complete! You can now explore the Lead Ingestion pattern in your org."

If any fail → "Some records may not have been created. Check the Platform Event flow for errors in Setup > Flows."

---

## Cleanup (Optional)

If the user asks to clean up, run:
```bash
sf apex run --file cleanup_demo_data.apex --target-org <ORG_ALIAS>
```
